# Memory

<p align="center"><img style="text-align: center;" src="/assets/memory.png?raw=true"></p>
A simple yet fun card game in which all of the cards are laid face down on a surface and two cards are flipped face up over each turn. The object of the game is to turn over pairs of matching cards.

Powered by Angular2
<p align="center"><img style="text-align: center;" src="/assets/screenshot.png?raw=true"></p>

## Author

 **[Murhaf Sousli](http://murhafsousli.com)**

 - [github/murhafsousli](https://github.com/MurhafSousli)
 - [twitter/murhafsousli](https://twitter.com/MurhafSousli)

## License

[![AUR](https://img.shields.io/aur/license/yaourt.svg?style=flat-square)](/LICENSE)