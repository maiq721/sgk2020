/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ResultComponent } from './result.component';

describe('Component: Result', () => {
  it('should create an instance', () => {
    let component = new ResultComponent();
    expect(component).toBeTruthy();
  });
});
