/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ResultPipe } from './result.pipe';

describe('Pipe: Result', () => {
  it('create an instance', () => {
    let pipe = new ResultPipe();
    expect(pipe).toBeTruthy();
  });
});
