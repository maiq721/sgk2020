/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ColorsBarComponent } from './colors-bar.component';

describe('Component: ColorsBar', () => {
  it('should create an instance', () => {
    let component = new ColorsBarComponent();
    expect(component).toBeTruthy();
  });
});
