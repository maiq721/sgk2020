/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { HtmlSanitizerPipe } from './html-sanitizer.pipe';

describe('Pipe: HtmlSanitizer', () => {
  it('create an instance', () => {
    let pipe = new HtmlSanitizerPipe();
    expect(pipe).toBeTruthy();
  });
});
