export class Card {
  flipped: boolean;

  constructor(public id: string, public template: string) {
  }

}
