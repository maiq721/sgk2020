import {Component, ChangeDetectionStrategy} from '@angular/core';

@Component({
  selector: 'logo',
  templateUrl: './logo.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LogoComponent {

}
