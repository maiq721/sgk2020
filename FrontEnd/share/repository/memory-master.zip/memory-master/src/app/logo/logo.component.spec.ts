/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { LogoComponent } from './logo.component';

describe('Component: Logo', () => {
  it('should create an instance', () => {
    let component = new LogoComponent();
    expect(component).toBeTruthy();
  });
});
