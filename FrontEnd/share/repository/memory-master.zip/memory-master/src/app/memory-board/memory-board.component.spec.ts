/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { MemoryBoardComponent } from './memory-board.component';

describe('Component: MemoryBoard', () => {
  it('should create an instance', () => {
    let component = new MemoryBoardComponent();
    expect(component).toBeTruthy();
  });
});
