/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { MemoryCardComponent } from './memory-card.component';

describe('Component: MemoryCard', () => {
  it('should create an instance', () => {
    let component = new MemoryCardComponent();
    expect(component).toBeTruthy();
  });
});
