/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { AboutComponent } from './about.component';

describe('Component: About', () => {
  it('should create an instance', () => {
    let component = new AboutComponent();
    expect(component).toBeTruthy();
  });
});
