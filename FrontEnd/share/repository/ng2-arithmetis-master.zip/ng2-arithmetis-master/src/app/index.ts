export {environment} from './environment';
export {ArithmetisAppComponent} from './arithmetis.component';
