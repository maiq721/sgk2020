export { MenuAboutComponent } from './menu-about.component';
