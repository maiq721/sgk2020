export { MenuScoresComponent } from './menu-scores.component';
