export { MenuLeaderboardsComponent } from './menu-leaderboards.component';
