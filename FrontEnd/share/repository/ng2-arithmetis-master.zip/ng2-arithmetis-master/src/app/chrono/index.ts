export { ChronoComponent } from './chrono.component';
