export { SquareComponent } from './square.component';
